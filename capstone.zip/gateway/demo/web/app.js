const $ = id => document.getElementById(id);
const scenarios = {
  current: { title: 'A legitimate client request', description: 'The current token matches the gateway’s clock. The gateway removes it and forwards your request.', icon: '✓' },
  previous: { title: 'A little grace at the boundary', description: 'The previous window is still accepted, allowing requests sent just before a token rotation to arrive safely.', icon: '↻' },
  expired: { title: 'Replay a token from three windows ago', description: 'This token has aged out of the acceptance window. Expect a 404, with no backend invocation.', icon: '◷' },
  static: { title: 'Try the original, predictable address', description: 'A scanner calls the plain API route without a token. The gateway rejects it before the backend runs.', icon: '⊘' },
  future: { title: 'A client clock that is ahead', description: 'A next-window token is not valid yet. Only current and previous windows are accepted.', icon: '↗' },
  invalid: { title: 'An altered route token', description: 'A non-hexadecimal token cannot match the HMAC result. The gateway rejects this tampered address.', icon: '✕' },
};
const example = $('payload').value;
let state = null, clockOffset = 0, online = false, busy = false, polling = false;
let selected = null, activeTab = 'response', selectedID = null, nextAuto = 0;
const responses = new Map();
function text(id, value) { $(id).textContent = value; }
function duration(value) { return value < 0.01 ? '<0.01 ms' : `${value.toFixed(2)} ms`; }
function showError(message = '') { text('form-error', message); $('form-error').hidden = !message; }
function setConnection(ok) {
  online = ok;
  $('connection').classList.toggle('offline', !ok);
  text('connection-text', ok ? 'Gateway connected' : 'Gateway disconnected');
  $('send').disabled = !ok || busy;
  $('suite').disabled = !ok || busy;
  if (!ok) { $('auto').checked = false; text('current-token', '••••••••'); text('countdown', '—'); }
}
function requestPath(scenario) {
  if (!state) return '';
  if (scenario === 'static') return '/api/v1/checkout';
  return `/api/v1/${scenario === 'invalid' ? 'zzzzzzzz' : state.tokens[scenario]}/checkout`;
}
function updateScenario() {
  const scenario = scenarios[$('scenario').value];
  text('scenario-title', scenario.title); text('scenario-description', scenario.description); text('scenario-icon', scenario.icon);
  text('route-preview', online ? requestPath($('scenario').value) : 'Waiting for gateway…');
  $('payload').disabled = $('method').value === 'GET';
  text('payload-help', $('method').value === 'GET' ? 'GET requests have no body. Switch to POST to send your JSON.' : 'Edit this payload and find the exact body in the backend response.');
}
async function refresh() {
  if (polling) return;
  polling = true;
  try {
    const response = await fetch('/demo/state', { cache: 'no-store', signal: AbortSignal.timeout(4000) });
    if (!response.ok) throw new Error(`Gateway returned ${response.status}`);
    state = await response.json();
    clockOffset = state.serverTime - Date.now();
    setConnection(true);
    text('current-token', state.tokens.current); text('previous-token', state.tokens.previous);
    text('window-label', `${state.windowSeconds}-second window`); text('interval-label', `Window ${state.interval.toLocaleString()}`);
    for (const [id, key] of [['total','total'], ['forwarded','forwarded'], ['blocked','blocked'], ['backend','backendResponses']]) text(`stat-${id}`, state.counts[key]);
    updateScenario(); renderActivity(); tick();
  } catch { setConnection(false); text('route-preview', 'Gateway unavailable — reconnecting automatically'); }
  finally { polling = false; }
}
function tick() {
  if (!state || !online) return;
  const remaining = Math.max(0, state.nextRotation - Date.now() - clockOffset);
  text('countdown', `${Math.ceil(remaining / 1000)}s`);
  $('rotation-progress').value = remaining / (state.windowSeconds * 1000) * 100;
  if ($('auto').checked && !busy && Date.now() >= nextAuto) { nextAuto = Date.now() + 3000; runSingle(); }
}
function setBusy(value) {
  busy = value; $('send').disabled = value || !online; $('suite').disabled = value || !online;
  $('scenario').disabled = value; $('method').disabled = value;
  $('send').firstElementChild.textContent = value ? 'Sending through gateway…' : 'Send request';
}
function validateBody() {
  if ($('method').value !== 'GET') {
    try { JSON.parse($('payload').value); } catch { throw new Error('Your request body is not valid JSON. Check quotes, commas, and brackets, or reset the example.'); }
  }
}
async function sendScenario(scenario) {
  // Refresh immediately before sending so boundary tests use the server’s clock.
  const snapshot = await fetch('/demo/state', { cache: 'no-store', signal: AbortSignal.timeout(4000) });
  if (!snapshot.ok) throw new Error('Could not read the gateway clock. Check that demo mode is running.');
  state = await snapshot.json();
  const requestID = crypto.randomUUID();
  const path = requestPath(scenario);
  const method = $('method').value;
  const start = performance.now();
  const response = await fetch(path, { method, headers: { 'Content-Type': 'application/json', 'X-Demo-Request-ID': requestID },
    body: method === 'GET' ? undefined : $('payload').value, cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(15000) });
  const body = await response.text();
  const roundTripMs = performance.now() - start;
  responses.set(requestID, { body, status: response.status, roundTripMs });
  if (responses.size > 100) responses.delete(responses.keys().next().value);
  await refresh();
  const event = state.events.find(item => item.requestId === requestID);
  if (event) { inspect(event); renderActivity(); }
  else { selected = null; renderInspector(body); text('response-meta', `HTTP ${response.status}`); text('journey-explanation', 'Response received. Its server trace has not appeared yet; select it from activity when available.'); }
  return response.status;
}
async function runSingle() {
  if (busy || !online) return;
  showError();
  try {
    validateBody(); setBusy(true);
    const code = await sendScenario($('scenario').value);
    text('run-status', `Request complete · HTTP ${code}. Inspect the recorded journey on the right.`);
  } catch (error) { showError(error.message); $('auto').checked = false; text('run-status', 'Request could not complete. Review the error and try again.'); }
  finally { setBusy(false); nextAuto = Date.now() + 3000; }
}
async function runSuite() {
  if (busy || !online) return;
  showError(); $('auto').checked = false;
  try {
    validateBody(); setBusy(true);
    let passed = 0;
    for (const [index, scenario] of Object.keys(scenarios).entries()) {
      $('scenario').value = scenario; updateScenario();
      text('run-status', `Running scenario ${index + 1} of 6: ${scenarios[scenario].title}…`);
      const status = await sendScenario(scenario);
      const expected = ['current', 'previous'].includes(scenario) ? 200 : 404;
      if (status === expected) passed++;
    }
    text('run-status', `${passed}/6 scenarios matched the expected result. Select any request below to explore it.`);
  } catch (error) { showError(error.message); text('run-status', 'Suite interrupted. Completed requests remain in activity.'); }
  finally { setBusy(false); }
}
function inspect(event) {
  selected = event; selectedID = event.id;
  const forwarded = event.backendAttempted, responded = event.backendResponded;
  text('journey-status', !forwarded ? 'BLOCKED AT GATEWAY' : responded ? 'BACKEND RESPONDED' : 'UPSTREAM UNAVAILABLE');
  $('journey-status').className = `pill ${!forwarded ? 'blocked' : responded ? 'success' : 'error'}`;
  $('stage-client').className = 'stage passed';
  $('stage-gateway').className = `stage ${forwarded ? 'passed' : 'blocked'}`;
  $('stage-backend').className = `stage ${responded ? 'passed' : forwarded ? 'blocked' : 'inactive'}`;
  $('connector-one').className = 'connector passed';
  $('connector-two').className = `connector ${forwarded ? 'passed' : 'blocked'}`;
  text('client-detail', `${event.method} request sent`);
  text('gateway-detail', forwarded ? 'Token accepted · path rewritten' : 'Route rejected · HTTP 404');
  text('backend-detail', responded ? `Responded with HTTP ${event.status}` : forwarded ? 'No upstream response' : 'Not invoked');
  text('journey-explanation', !forwarded ? 'Stopped at the perimeter. The route failed validation, so the backend was never invoked.' : responded ? 'Token accepted. The gateway stripped the token and received a real response from the backend.' : 'The route passed validation, but the proxy could not obtain a backend response. Check the backend process.');
  text('trace-incoming', event.incoming); text('trace-forwarded', event.forwarded || 'Not forwarded — blocked at gateway');
  const response = responses.get(event.requestId);
  text('response-meta', `HTTP ${event.status} · ${duration(event.durationMs)} server`);
  renderInspector(response?.body);
}
function renderInspector(body) {
  let content;
  if (activeTab === 'trace') content = selected ? JSON.stringify(selected, null, 2) : '// Select a request to inspect its server trace.';
  else {
    body ??= selected ? responses.get(selected.requestId)?.body : undefined;
    if (body === undefined) content = '// Response body is available for requests sent from this browser tab.\n// Select Gateway trace to see the server-recorded event.';
    else { try { content = JSON.stringify(JSON.parse(body), null, 2); } catch { content = body; } }
  }
  text('response-body', content);
}
function renderActivity() {
  if (!state) return;
  const filter = $('filter').value;
  const events = state.events.filter(event => filter === 'all' || (filter === 'forwarded' ? event.backendAttempted : !event.backendAttempted));
  const signature = `${state.started}:${state.counts.total}:${filter}:${selectedID}`;
  if ($('activity-rows').dataset.signature === signature) return;
  $('activity-rows').dataset.signature = signature;
  $('activity-rows').replaceChildren();
  for (const event of events) {
    const row = document.createElement('tr');
    if (event.id === selectedID) row.className = 'selected';
    const values = [new Date(event.time).toLocaleTimeString([], { hour12: false }), `${event.method} ${event.incoming}`, `${event.status} · ${event.backendAttempted ? 'Forwarded' : 'Blocked'}`, event.backendResponded ? 'Responded' : event.backendAttempted ? 'Unavailable' : 'Not invoked', duration(event.durationMs)];
    values.forEach((value, index) => {
      const cell = document.createElement('td');
      const child = document.createElement(index === 1 ? 'code' : 'span'); child.textContent = value;
      if (index === 2) child.className = `pill ${event.backendAttempted ? event.backendResponded ? 'success' : 'error' : 'blocked'}`;
      cell.append(child); row.append(cell);
    });
    const cell = document.createElement('td'), button = document.createElement('button');
    button.className = 'inspect-button'; button.textContent = '↗'; button.setAttribute('aria-label', `Inspect request ${event.id}`);
    cell.append(button); row.append(cell);
    row.addEventListener('click', () => {
      inspect(event); renderActivity();
      $('journey-title').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
    });
    $('activity-rows').append(row);
  }
  $('activity-empty').hidden = events.length > 0;
  if (!events.length) {
    $('activity-empty').querySelector('strong').textContent = filter !== 'all' ? 'No requests match this filter' : 'A clear view of every request';
    $('activity-empty').querySelector('p').textContent = filter !== 'all' ? 'Choose All requests or send a matching test scenario.' : 'Send your first request above. Live gateway activity will appear here.';
  }
  text('activity-count', `${events.length} shown · ${state.counts.total} requests since gateway start`);
}
$('scenario').addEventListener('change', updateScenario);
$('method').addEventListener('change', updateScenario);
$('send').addEventListener('click', runSingle);
$('suite').addEventListener('click', runSuite);
$('filter').addEventListener('change', renderActivity);
$('reset-payload').addEventListener('click', () => { $('payload').value = example; showError(); });
$('auto').addEventListener('change', () => { nextAuto = Date.now(); text('run-status', $('auto').checked ? 'Live repeat enabled. One request every 3 seconds; turn off to stop.' : 'Live repeat paused.'); });
for (const tab of ['response','trace']) $('tab-' + tab).addEventListener('click', () => {
  activeTab = tab;
  for (const name of ['response','trace']) { $('tab-' + name).classList.toggle('selected', name === tab); $('tab-' + name).setAttribute('aria-selected', String(name === tab)); }
  $('response-panel').setAttribute('aria-labelledby', 'tab-' + tab); renderInspector();
});
$('copy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('response-body').textContent); text('copy', 'Copied'); setTimeout(() => text('copy', 'Copy'), 1500); }
  catch { text('copy', 'Select text to copy'); }
});
$('export').addEventListener('click', () => {
  if (!state) return;
  const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), counts: state.counts, events: state.events }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob), link = document.createElement('a'); link.href = url; link.download = 'flux-request-activity.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
});
document.querySelectorAll('nav a').forEach(link => link.addEventListener('click', () => { document.querySelectorAll('nav a').forEach(item => item.classList.toggle('active', item === link)); }));
document.addEventListener('visibilitychange', () => { if (document.hidden) $('auto').checked = false; else refresh(); });
await refresh();
setInterval(refresh, 1000);
setInterval(tick, 100);
